var x=5,y=6;
var z=x+y;
document.write("</br>","sum of x and y is:",z);
document.write("</br>","x is ",x);
document.write("</br>"," y is ",y);

// second program of JS
var num=100;
var str="kamlesh";
var bool=true;

document.write("</br>",typeof(num));
document.write("</br>",typeof(str));
document.write("</br>",typeof(bool));

// Third program of JS
var car = {
    modal: "BMW X3",
    color: "WHite",
    doors: 5
}
document.write("</br>"+car.modal+" "+car.color+" "+car.doors);
var cars = ["BMW","Mercedes Benz","Volkswagen"];
document.write("</br>"+cars[0]);
document.write("</br>"+cars[1]);
document.write("</br>"+cars[2]);
